const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");

const responses = {
  "hi": "Hello! 👋",
  "how are you": "I'm just a bot, but I'm doing great! 😄",
  "what is your name": "I'm ChatBot 1.0 🤖",
  "bye": "Goodbye! Have a great day! 👋",
  "thanks": "You're welcome! 😊",
  "who created you": "I was built by a developer using JavaScript 🧠",
};

function addMessage(message, sender) {
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message", sender);
  msgDiv.innerText = message;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function sendMessage() {
  const msg = userInput.value.trim();
  if (msg === "") return;

  addMessage(`You: ${msg}`, "user");

  const lowerMsg = msg.toLowerCase();
  const reply = responses[lowerMsg] || "Sorry, I don't understand that. 🤔";
  setTimeout(() => addMessage(`Bot: ${reply}`, "bot"), 500);

  userInput.value = "";
}

function handleEnter(e) {
  if (e.key === "Enter") {
    sendMessage();
  }
}

// 🎙️ Bonus: Speech Recognition
function startListening() {
  if (!('webkitSpeechRecognition' in window)) {
    alert("Speech recognition not supported in your browser.");
    return;
  }

  const recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;

  recognition.start();

  recognition.onresult = function(event) {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    sendMessage();
  };

  recognition.onerror = function(event) {
    alert("Speech error: " + event.error);
  };
}
