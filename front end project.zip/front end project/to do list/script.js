let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

const taskList = document.getElementById("taskList");
const taskInput = document.getElementById("taskInput");
const dueDate = document.getElementById("dueDate");
const priority = document.getElementById("priority");
const search = document.getElementById("search");
const filterStatus = document.getElementById("filterStatus");

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
  taskList.innerHTML = "";
  const filtered = tasks.filter(task => {
    const matchesSearch = task.text.toLowerCase().includes(search.value.toLowerCase());
    const matchesStatus = filterStatus.value === "all" ||
      (filterStatus.value === "completed" && task.completed) ||
      (filterStatus.value === "uncompleted" && !task.completed);
    return matchesSearch && matchesStatus;
  });

  filtered.forEach((task, index) => {
    const li = document.createElement("li");
    li.draggable = true;
    li.dataset.index = index;

    if (task.completed) li.classList.add("completed");

    li.innerHTML = `
      <span class="task-text">
        ${task.text} 
        <small>[${task.priority}] - Due: ${task.dueDate}</small>
      </span>
      <div class="task-actions">
        <button onclick="toggleComplete(${index})">✅</button>
        <button onclick="editTask(${index})">✏️</button>
        <button onclick="deleteTask(${index})">🗑️</button>
      </div>
    `;

    li.addEventListener("dragstart", dragStart);
    li.addEventListener("dragover", dragOver);
    li.addEventListener("drop", drop);
    taskList.appendChild(li);
  });

  saveTasks();
}

function addTask() {
  const text = taskInput.value.trim();
  if (text === "") return;

  tasks.push({
    text,
    dueDate: dueDate.value || "No date",
    priority: priority.value,
    completed: false
  });

  taskInput.value = "";
  dueDate.value = "";
  renderTasks();
}

function toggleComplete(index) {
  tasks[index].completed = !tasks[index].completed;
  renderTasks();
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

function editTask(index) {
  const newText = prompt("Edit task:", tasks[index].text);
  if (newText) {
    tasks[index].text = newText;
    renderTasks();
  }
}

function filterTasks() {
  renderTasks();
}

function toggleDarkMode() {
  document.body.classList.toggle("dark");
}

// Drag and Drop Logic
let dragStartIndex;
function dragStart(e) {
  dragStartIndex = +e.target.dataset.index;
}

function dragOver(e) {
  e.preventDefault();
}

function drop(e) {
  const dragEndIndex = +e.target.closest("li").dataset.index;
  const draggedItem = tasks[dragStartIndex];
  tasks.splice(dragStartIndex, 1);
  tasks.splice(dragEndIndex, 0, draggedItem);
  renderTasks();
}

// Initial render
renderTasks();
