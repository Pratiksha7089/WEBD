const balanceElement = document.getElementById("balance");
const incomeElement = document.getElementById("income");
const expenseElement = document.getElementById("expense");
const transactionList = document.getElementById("transaction-list");
const transactionForm = document.getElementById("transaction-form");
const descriptionInput = document.getElementById("description");
const amountInput = document.getElementById("amount");
const dateInput = document.getElementById("date");
const categoryInput = document.getElementById("category");
const filterMonth = document.getElementById("filter-month");
const filterYear = document.getElementById("filter-year");

let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

function updateUI(filteredTransactions = transactions) {
    transactionList.innerHTML = "";
    let income = 0, expense = 0, totalBalance = 0;

    filteredTransactions.forEach((transaction, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${transaction.date} - ${transaction.category} - ${transaction.description} - $${transaction.amount}`;
        listItem.style.borderLeftColor = transaction.amount > 0 ? "green" : "red";

        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "X";
        deleteBtn.classList.add("delete-btn");
        deleteBtn.onclick = () => removeTransaction(index);
        listItem.appendChild(deleteBtn);

        transactionList.appendChild(listItem);

        if (transaction.amount > 0) {
            income += transaction.amount;
        } else {
            expense += Math.abs(transaction.amount);
        }
        totalBalance += transaction.amount;
    });

    balanceElement.textContent = `$${totalBalance.toFixed(2)}`;
    incomeElement.textContent = `$${income.toFixed(2)}`;
    expenseElement.textContent = `$${expense.toFixed(2)}`;

    updateChart(income, expense);
}

function addTransaction(event) {
    event.preventDefault();

    const description = descriptionInput.value;
    const amount = parseFloat(amountInput.value);
    const date = dateInput.value;
    const category = categoryInput.value;

    if (!description || isNaN(amount) || !date || !category) {
        alert("Please enter valid details!");
        return;
    }

    transactions.push({ description, amount, date, category });
    localStorage.setItem("transactions", JSON.stringify(transactions));
    updateUI();

    transactionForm.reset();
}

function removeTransaction(index) {
    transactions.splice(index, 1);
    localStorage.setItem("transactions", JSON.stringify(transactions));
    updateUI();
}

function applyFilters() {
    const month = filterMonth.value;
    const year = filterYear.value;

    const filtered = transactions.filter(transaction => {
        return (!month || transaction.date.includes(`-${month}-`)) &&
               (!year || transaction.date.includes(year));
    });

    updateUI(filtered);
}

let chart;
function updateChart(income, expense) {
    if (chart) chart.destroy();
    const ctx = document.getElementById("expenseChart").getContext("2d");
    chart = new Chart(ctx, { type: "doughnut", data: { labels: ["Income", "Expense"], datasets: [{ data: [income, expense], backgroundColor: ["green", "red"] }] } });
}

transactionForm.addEventListener("submit", addTransaction);
updateUI();
