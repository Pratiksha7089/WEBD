const apiKey = "fe40bc4b3b0597479f1eb232b9b15007"; // Replace with your OpenWeatherMap API Key

async function getWeather(city) {
    if (!city) {
        city = document.getElementById("city").value.trim();
        if (!city) {
            alert("Please enter a city name!");
            return;
        }
    }

    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const [weatherResponse, forecastResponse] = await Promise.all([
            fetch(weatherUrl),
            fetch(forecastUrl)
        ]);

        if (!weatherResponse.ok || !forecastResponse.ok) {
            throw new Error("City not found");
        }

        const weatherData = await weatherResponse.json();
        const forecastData = await forecastResponse.json();

        displayWeather(weatherData);
        displayForecast(forecastData);
    } catch (error) {
        alert(error.message);
    }
}

function displayWeather(data) {
    document.getElementById("city-name").textContent = `Weather in ${data.name}`;
    document.getElementById("temperature").textContent = `🌡️ Temperature: ${data.main.temp}°C`;
    document.getElementById("weather-condition").textContent = `☁️ Condition: ${data.weather[0].description}`;
    document.getElementById("humidity").textContent = `💧 Humidity: ${data.main.humidity}%`;
    document.getElementById("weather-icon").src = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;

    document.querySelector(".weather-info").style.display = "block";
}

function displayForecast(data) {
    const forecastContainer = document.getElementById("forecast-container");
    forecastContainer.innerHTML = "";

    const filteredForecast = data.list.filter((item) => item.dt_txt.includes("12:00:00"));

    filteredForecast.forEach((forecast) => {
        const forecastCard = document.createElement("div");
        forecastCard.classList.add("forecast-card");

        const date = new Date(forecast.dt_txt);
        const day = date.toLocaleDateString("en-US", { weekday: "short" });

        forecastCard.innerHTML = `
            <p>${day}</p>
            <img src="https://openweathermap.org/img/wn/${forecast.weather[0].icon}.png" alt="${forecast.weather[0].description}">
            <p>${forecast.main.temp}°C</p>
        `;

        forecastContainer.appendChild(forecastCard);
    });
}

// Get user's current location weather
function getCurrentLocationWeather() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`;
            const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`;

            try {
                const [weatherResponse, forecastResponse] = await Promise.all([
                    fetch(weatherUrl),
                    fetch(forecastUrl)
                ]);

                if (!weatherResponse.ok || !forecastResponse.ok) {
                    throw new Error("Unable to fetch location weather");
                }

                const weatherData = await weatherResponse.json();
                const forecastData = await forecastResponse.json();

                displayWeather(weatherData);
                displayForecast(forecastData);
            } catch (error) {
                alert(error.message);
            }
        }, () => {
            alert("Location access denied.");
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}
